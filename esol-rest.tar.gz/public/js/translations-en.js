Em.I18n.translations = {
		
'search.searchlabel' : 'Search courses',
'main.paragraph' : 'If you live in Newham and want to improve your English, this website is for you.  More than xxx courses to choose from.'
	
};
