Em.I18n.translations = {
		
'search.searchlabel' : 'Search courses',
'main.paragraph' : 'Si usted vive en Newham y desea mejorar su Inglés, este sitio web es para usted. Más de xxxx cursos para elegir.'
	
};
