// public/js/app.js
Esol = Ember.Application.create();


